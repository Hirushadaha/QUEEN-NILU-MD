<p align="center"> 
  <p align="center">
  <a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Bungee+Shade&size=25&pause=1000&background=FF000000&width=435&lines=Queen+Nilu+Md+;Created+By+Janiya" alt="Typing SVG" /></a>
</p> 
  
<p align="center"> 
<img src="https://telegra.ph/file/1e63f0ee90304a12767c7.jpg" width="300" height="300"/>
</p>

<p align="center">
<a href="#"><img title="Creator" src="https://img.shields.io/badge/Creator-Janiya-blue.svg?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://github.com/Janithsadanuwan/Queen-Nilu-Md/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Janithsadanuwan/Queen-Nilu-Md?color=white&style=flat-square"></a>
<a href="https://github.com/Janithsadanuwan/Queen-Nilu-Md/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Janithsadanuwan/Queen-Nilu-Md?color=yellow&style=flat-square"></a>
<a href="https://github.com/Janithsadanuwan/Queen-Nilu-Md/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Janithsadanuwan/Queen-Nilu-Md?label=Watchers&color=red&style=flat-square"></a>
<a href="https://github.com/Janithsadanuwan/Queen-Nilu-Md/"><img title="Size" src="https://img.shields.io/github/repo-size/AlipBot/Api-Alpis?style=flat-square&color=darkred"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/Janithsadanuwan/Queen-Nilu-Md/%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=probot.svg&icon_color=%2304FF00&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Janithsadanuwan/Queen-Nilu-Md/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained-No-red.svg"></a>&nbsp;&nbsp;
</p> 

### Please Give One Star ✨ & [follow  me For notify my updates](https://github.com/Janithsadanuwan)

## [`Version --> 2.0.0`](https://www.janithsadanuwan.tech/QueenNilu)

### [Password]()
 ```
janith
```

## [`WebSite`](https://www.janithsadanuwan.tech/QueenNilu)


## [`FORK QUEEN NILU REPO`](https://github.com/Janithsadanuwan/Queen-Nilu-Md/fork)

## [`SCAN QR CODE`](https://www.janithsadanuwan.tech/QueenNilu/QrCode)

<details>
<summary>✨ How To Deploy Bot </summary>
<p>

 

  if there any error please infrom it support group ✨
# 

[`Deploy on Railway`](https://railway.app?referralCode=FnnJ_C)

[`Deploy on Koyeb`](https://app.koyeb.com/)

[`Deploy on Mogenius`](https://studio.mogenius.com/)

[`Deploy on Heroku`](https://heroku.com/deploy?template=)

[`Deploy on uffizzi`](https://www.uffizzi.com/)

[`Deploy on Replit`](https://replit.com/github/Janithsadanuwan/Queen-Nilu-Md)


## 𝗛𝗘𝗥𝗢𝗞𝗨 𝗧𝗘𝗠𝗣𝗟𝗔𝗧𝗘 𝗟𝗜𝗡𝗞
       
          https://heroku.com/deploy?template=https://github.com/Janithsadanuwan/QUEEN-NILU-MD

## [`WATCH YOUTUBE VIDEO`](https://youtu.be/)

+ DEPLOY STEPS
# 
1. Fork This Repository 
2. Update [config.js](https://github.com/Janithsadanuwan/QUEEN-NILU-MD/blob/main/config.js)
3. Update SESSION_ID 
4. Make acount on railway , heroku , mogenius or koyeb 
5. Connect Your Repository to your web host site
6. [ Watch Video](https://youtu.be/)
# 

 ## RAILWAY & KOYEB USERS :

01. Visit to your GitHub and open your Queen Nilu fork repo.
02. Under the green colour button as "Code" you will see "Sync fork" button. Click it.
03. Then, you will see green colour button as "Update branch". Click it.
04. Now, automatically bot will update.

  LOCAL OR VPS USERS :  
01. Visit to your GitHub and open your Queen Nilu fork repo.
02. Under the green colour button as "Code" you will see "Sync fork" button. Click it.
03. Then, you will see green colour button as "Update branch". Click it.
04. Open command prompt and command git clone your_fork_url
05. And it will update your files. Now, command cd QueenNilu && npm run pm-restart
   
   

01. Visit to your GitHub and open your Queen  Nilu fork repo.
02. Under the green colour button as "Code" you will see "Sync fork" button. Click it.
03. Then, you will see green colour button as "Update branch". Click it.
04. Connect to VPS and command git clone your_fork_url
05. And it will update your files. Now, command cd QueenNilu && npm run pm-restart
# 
# 

###  DEPLY ON TERMUX 
 ```   
apt update
apt upgrade
pkg update && pkg upgrade
pkg install bash
pkg install libwebp
pkg install git -y
pkg install nodejs -y 
pkg install ffmpeg -y 
pkg install wget
pkg install imagemagick -y
git clone https://github.com/Janithsadanuwan/Queen-Nilu-Md
cd Queen-Nilu-Md
npm install
npm start
```
</details>

<details>
<summary>ℹ️ How To Update Bot </summary>
<p>

# How to Update Bot 

<p align="left">
<img src="https://telegra.ph/file/6af1182fb6bf4b3a43e1d.jpg"/>
</p>
</details>

## Canot cannot copy or clone this repo 😂

[🧑‍💻 Join Queen Nilu Support Group 🧑‍💻](https://t.me/QueenNilu)

[💃 Join Public Group 💃]([https://chat.whatsapp.com/](https://chat.whatsapp.com/KT10WomWlnqLVm8iFL9aip))

![Visitor Count](https://profile-counter.glitch.me/Janithsadanuwan/count.svg)

## THANKS FOR USING QUEEN NILU 💃

## Thanks TO :
@adiwajshing - For baileys Web Api <br>
@nimesh-official - For Helps <br>
@vihangayt - For Helps <br>
@ravindumanoj - For Helps
& ALL
